sudo nautilus /opt/lampp/htdocs
