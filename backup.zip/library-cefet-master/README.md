# Projeto de Livraria em PHP

##Desenvolvido para Web
Linguagem:PHP
Banco:SQLite
CSS Framework: Semantic UI